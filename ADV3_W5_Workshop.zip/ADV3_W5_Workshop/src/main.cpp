#include <Arduino.h>
#include "Motor_control.h"
#include"Path_func.h"

void setup()
{
    Serial.begin(115200);
    motorSetup(10000, 2500);

    homePosition();
 

   



}

void loop()
{
  
}