#include <Arduino.h>
#include "Motor_control.h"
#include "path_functions.h"

void setup()
{
    Serial.begin(115200);
    motorSetup(10000, 2500);

    homePosition();
    delay(1000);  

    

    
    
 

   



}

void loop()
{
  
}