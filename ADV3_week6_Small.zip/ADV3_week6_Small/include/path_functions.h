#ifndef PATH_FUNCTIONS_H
#define PATH_FUNCTIONS_H

void Path1();
void Path2();
void Path3();
void Path4();

 
#endif
